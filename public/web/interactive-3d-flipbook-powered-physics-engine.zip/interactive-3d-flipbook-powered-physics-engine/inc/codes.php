<?php
  namespace iberezansky\fb3d;

  define('iberezansky\fb3d\CODE_OK', 0);
  define('iberezansky\fb3d\CODE_ERROR', 1);
  define('iberezansky\fb3d\CODE_NOT_FOUND', 3);
  define('iberezansky\fb3d\CODE_UNKNOWN', 4);
?>
